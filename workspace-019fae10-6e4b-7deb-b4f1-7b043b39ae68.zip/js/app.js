/**
 * ShadowVault Main Application Logic
 * Integrates WebCrypto, IndexedDB, UI Controllers, Canvas Censor Tool, and Stealth Modes.
 */

class ShadowVaultApp {
    constructor() {
        this.db = new VaultDB();
        this.currentCryptoKey = null;
        this.isDecoySession = false;
        this.currentAlbumId = 'all';
        this.currentMediaList = [];
        this.selectedMediaIds = new Set();
        this.viewMode = 'grid'; // 'grid' | 'list'
        
        // Input PIN state
        this.enteredPin = '';
        this.calcExpression = '';
        
        // Viewer state
        this.currentViewerIndex = -1;
        this.viewerZoom = 1;
        this.viewerRotation = 0;
        this.slideshowInterval = null;

        // Editor Canvas state
        this.editorCanvas = null;
        this.editorCtx = null;
        this.editorImg = null;
        this.isDrawingRect = false;
        this.rectStart = { x: 0, y: 0 };
        this.editorTool = 'blur'; // 'blur' | 'blackout'

        // Auto lock timer
        this.idleTimer = null;
        this.idleMinutes = parseInt(localStorage.getItem('vault_autolock_mins') || '3');

        // Decrypted Blob URL cache for RAM cleanup on lock
        this.blobUrls = [];
    }

    async init() {
        console.log("Initializing ShadowVault...");
        await this.db.init();
        this.bindEvents();
        this.checkInitialState();
        this.startIdleMonitor();
    }

    // --- INITIAL STATE & SETUP ---

    checkInitialState() {
        const salt = localStorage.getItem('vault_salt');
        const pinHash = localStorage.getItem('vault_pin_hash');
        const stealthMode = localStorage.getItem('vault_stealth_mode') === 'true';

        if (!salt || !pinHash) {
            // First time setup required
            this.showSetupModal();
        } else {
            if (stealthMode) {
                this.switchScreen('calculator-screen');
            } else {
                this.switchScreen('lock-screen');
            }
        }
    }

    showSetupModal() {
        document.getElementById('setup-modal').classList.add('active');
    }

    async setupVaultPasscode(passcode, decoyPasscode = '') {
        if (!passcode || passcode.length < 4) {
            this.showToast('Passcode must be at least 4 digits', 'error');
            return;
        }

        const saltBytes = VaultCrypto.randomBytes(16);
        const saltHex = VaultCrypto.bufferToHex(saltBytes);

        const pinHash = await VaultCrypto.hashPasscode(passcode, saltHex);
        localStorage.setItem('vault_salt', saltHex);
        localStorage.setItem('vault_pin_hash', pinHash);

        if (decoyPasscode && decoyPasscode.length >= 4) {
            const decoyHash = await VaultCrypto.hashPasscode(decoyPasscode, saltHex);
            localStorage.setItem('vault_decoy_hash', decoyHash);
        } else {
            localStorage.removeItem('vault_decoy_hash');
        }

        document.getElementById('setup-modal').classList.remove('active');
        this.showToast('Vault passcode created successfully!', 'success');
        
        // Auto-login with newly set passcode
        await this.unlockVault(passcode);
    }

    // --- AUTHENTICATION & UNLOCKING ---

    async handlePinInput(digit) {
        if (this.enteredPin.length < 6) {
            this.enteredPin += digit;
            this.updatePinDots();
        }

        if (this.enteredPin.length >= 4) {
            // Check passcode after entering 4-6 digits
            const saltHex = localStorage.getItem('vault_salt');
            const pinHash = localStorage.getItem('vault_pin_hash');
            const decoyHash = localStorage.getItem('vault_decoy_hash');

            const enteredHash = await VaultCrypto.hashPasscode(this.enteredPin, saltHex);

            if (enteredHash === pinHash) {
                await this.unlockVault(this.enteredPin, false);
            } else if (decoyHash && enteredHash === decoyHash) {
                await this.unlockVault(this.enteredPin, true);
            } else if (this.enteredPin.length === 6) {
                this.triggerPinError();
            }
        }
    }

    handlePinDelete() {
        if (this.enteredPin.length > 0) {
            this.enteredPin = this.enteredPin.slice(0, -1);
            this.updatePinDots();
        }
    }

    updatePinDots() {
        const dots = document.querySelectorAll('#pin-dots .dot');
        dots.forEach((dot, index) => {
            if (index < this.enteredPin.length) {
                dot.classList.add('filled');
            } else {
                dot.classList.remove('filled');
            }
        });
    }

    triggerPinError() {
        const dots = document.querySelectorAll('#pin-dots .dot');
        dots.forEach(dot => dot.classList.add('error'));
        this.showToast('Incorrect Passcode', 'error');

        setTimeout(() => {
            this.enteredPin = '';
            dots.forEach(dot => dot.classList.remove('filled', 'error'));
        }, 600);
    }

    // Calculator Stealth Input Handler
    async handleCalcInput(btnValue) {
        const display = document.getElementById('calc-display');

        if (btnValue === 'C') {
            this.calcExpression = '';
            display.innerText = '0';
        } else if (btnValue === '=') {
            // Check if entered value matches vault passcode
            const saltHex = localStorage.getItem('vault_salt');
            const pinHash = localStorage.getItem('vault_pin_hash');
            const decoyHash = localStorage.getItem('vault_decoy_hash');

            if (saltHex && pinHash) {
                const enteredHash = await VaultCrypto.hashPasscode(this.calcExpression, saltHex);
                if (enteredHash === pinHash) {
                    this.calcExpression = '';
                    display.innerText = '0';
                    await this.unlockVault(this.calcExpression, false);
                    return;
                } else if (decoyHash && enteredHash === decoyHash) {
                    this.calcExpression = '';
                    display.innerText = '0';
                    await this.unlockVault(this.calcExpression, true);
                    return;
                }
            }

            // Standard calculator evaluate if not unlocking
            try {
                // Safe evaluate simple arithmetic expression
                const sanitized = this.calcExpression.replace(/×/g, '*').replace(/÷/g, '/');
                const result = eval(sanitized);
                display.innerText = String(result).substring(0, 10);
                this.calcExpression = String(result);
            } catch {
                display.innerText = 'Error';
                this.calcExpression = '';
            }
        } else {
            if (display.innerText === '0' || display.innerText === 'Error') {
                this.calcExpression = btnValue;
            } else {
                this.calcExpression += btnValue;
            }
            display.innerText = this.calcExpression;
        }
    }

    async unlockVault(passcode, isDecoy = false) {
        try {
            const saltHex = localStorage.getItem('vault_salt');
            const saltBytes = VaultCrypto.hexToBuffer(saltHex);

            this.currentCryptoKey = await VaultCrypto.deriveKey(passcode, saltBytes);
            this.isDecoySession = isDecoy;

            this.enteredPin = '';
            this.updatePinDots();

            // Update mode badge
            const badge = document.getElementById('vault-mode-badge');
            if (isDecoy) {
                badge.className = 'badge-mode badge-decoy';
                badge.innerText = 'Decoy Vault Mode';
            } else {
                badge.className = 'badge-mode badge-main';
                badge.innerText = 'AES-256 Encrypted';
            }

            this.switchScreen('app-screen');
            await this.loadAlbums();
            await this.loadGallery();

            this.showToast(isDecoy ? 'Opened Decoy Vault' : 'Vault Unlocked!', 'success');
        } catch (err) {
            console.error("Unlock error:", err);
            this.showToast('Failed to derive encryption key', 'error');
        }
    }

    lockVault() {
        // Clear cryptographic keys and blob URLs from RAM
        this.currentCryptoKey = null;
        this.clearBlobUrls();
        this.selectedMediaIds.clear();

        const stealthMode = localStorage.getItem('vault_stealth_mode') === 'true';
        if (stealthMode) {
            this.switchScreen('calculator-screen');
        } else {
            this.switchScreen('lock-screen');
        }

        this.showToast('Vault Locked', 'info');
    }

    clearBlobUrls() {
        this.blobUrls.forEach(url => URL.revokeObjectURL(url));
        this.blobUrls = [];
    }

    switchScreen(screenId) {
        document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
        const target = document.getElementById(screenId);
        if (target) target.classList.add('active');
    }

    // --- ALBUM MANAGEMENT ---

    async loadAlbums() {
        const albumListEl = document.getElementById('custom-albums-list');
        albumListEl.innerHTML = '';

        const albums = await this.db.getAlbums(this.isDecoySession);

        albums.forEach(album => {
            const item = document.createElement('div');
            item.className = `nav-item ${this.currentAlbumId === album.id ? 'active' : ''}`;
            item.dataset.albumId = album.id;
            item.innerHTML = `
                <div class="nav-item-left">
                    <span>${album.icon || '📁'}</span>
                    <span>${this.escapeHtml(album.name)}</span>
                </div>
                <button class="fav-btn btn-delete-album" style="font-size:12px; opacity:0.6;" title="Delete Album">✕</button>
            `;

            item.addEventListener('click', (e) => {
                if (e.target.classList.contains('btn-delete-album')) {
                    e.stopPropagation();
                    this.deleteAlbum(album.id, album.name);
                } else {
                    this.switchAlbum(album.id, album.name);
                }
            });

            albumListEl.appendChild(item);
        });
    }

    async createAlbum() {
        const albumName = prompt("Enter new album name:");
        if (!albumName || !albumName.trim()) return;

        const album = {
            id: 'album_' + Date.now(),
            name: albumName.trim(),
            icon: '🖼️',
            color: '#6366f1',
            dateCreated: Date.now(),
            isDecoy: this.isDecoySession
        };

        await this.db.saveAlbum(album);
        await this.loadAlbums();
        this.showToast(`Album "${album.name}" created`, 'success');
    }

    async deleteAlbum(albumId, albumName) {
        if (confirm(`Delete album "${albumName}"? Photos inside will be moved to Uncategorized.`)) {
            await this.db.deleteAlbum(albumId);
            if (this.currentAlbumId === albumId) {
                this.switchAlbum('all', 'All Media');
            }
            await this.loadAlbums();
            this.showToast(`Album "${albumName}" deleted`, 'info');
        }
    }

    switchAlbum(albumId, title) {
        this.currentAlbumId = albumId;
        document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
        
        const activeItem = document.querySelector(`.nav-item[data-album-id="${albumId}"]`);
        if (activeItem) activeItem.classList.add('active');

        document.getElementById('current-album-title').innerText = title || 'Media';
        this.loadGallery();
    }

    // --- MEDIA UPLOAD & ENCRYPTION ---

    async handleFileUpload(files) {
        if (!this.currentCryptoKey) {
            this.showToast('Vault is locked!', 'error');
            return;
        }

        const fileList = Array.from(files);
        if (fileList.length === 0) return;

        this.showToast(`Encrypting & storing ${fileList.length} item(s)...`, 'info');

        for (const file of fileList) {
            try {
                const arrayBuffer = await file.arrayBuffer();
                const isVideo = file.type.startsWith('video/');

                // Encrypt payload
                const encrypted = await VaultCrypto.encryptData(arrayBuffer, this.currentCryptoKey);

                const mediaRecord = {
                    id: 'media_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
                    name: file.name,
                    type: isVideo ? 'video' : 'image',
                    mimeType: file.type || (isVideo ? 'video/mp4' : 'image/jpeg'),
                    size: file.size,
                    albumId: this.currentAlbumId === 'all' ? 'uncategorized' : this.currentAlbumId,
                    isFavorite: false,
                    isDecoy: this.isDecoySession,
                    dateAdded: new Date().toISOString(),
                    iv: encrypted.iv,
                    encryptedBlob: encrypted.ciphertext
                };

                await this.db.saveMedia(mediaRecord);
            } catch (err) {
                console.error("Error encrypting file:", file.name, err);
                this.showToast(`Failed to encrypt ${file.name}`, 'error');
            }
        }

        this.showToast('Files encrypted and stored safely!', 'success');
        await this.loadGallery();
        await this.updateStorageUsage();
    }

    // --- GALLERY RENDERING & DECRYPTION ---

    async loadGallery() {
        const grid = document.getElementById('gallery-grid');
        const emptyState = document.getElementById('empty-state');
        grid.innerHTML = '';
        this.clearBlobUrls();

        let items = await this.db.getAllMedia(this.isDecoySession);

        // Filter by album/type
        if (this.currentAlbumId === 'favorites') {
            items = items.filter(i => i.isFavorite);
        } else if (this.currentAlbumId === 'videos') {
            items = items.filter(i => i.type === 'video');
        } else if (this.currentAlbumId !== 'all') {
            items = items.filter(i => i.albumId === this.currentAlbumId);
        }

        // Filter by search query
        const searchQuery = document.getElementById('search-input').value.toLowerCase().trim();
        if (searchQuery) {
            items = items.filter(i => i.name.toLowerCase().includes(searchQuery));
        }

        this.currentMediaList = items;
        this.updateNavCounts(items.length);

        if (items.length === 0) {
            grid.style.display = 'none';
            emptyState.style.display = 'block';
            return;
        }

        grid.style.display = this.viewMode === 'grid' ? 'grid' : 'flex';
        emptyState.style.display = 'none';

        // Render each item
        for (let index = 0; index < items.length; index++) {
            const media = items[index];
            const card = document.createElement('div');
            card.className = `media-card ${this.selectedMediaIds.has(media.id) ? 'selected' : ''}`;
            card.dataset.id = media.id;

            // Decrypt image/video payload on demand for preview
            let mediaUrl = '';
            try {
                const decryptedBuf = await VaultCrypto.decryptData(media.encryptedBlob, this.currentCryptoKey, media.iv);
                const blob = new Blob([decryptedBuf], { type: media.mimeType });
                mediaUrl = URL.createObjectURL(blob);
                this.blobUrls.push(mediaUrl);
            } catch (e) {
                console.error("Preview decryption error:", media.id, e);
            }

            const isSelected = this.selectedMediaIds.has(media.id);

            card.innerHTML = `
                ${media.type === 'video' ? `
                    <video src="${mediaUrl}#t=0.5" preload="metadata" muted></video>
                    <span class="badge-video">▶ VIDEO</span>
                ` : `
                    <img src="${mediaUrl}" alt="${this.escapeHtml(media.name)}" loading="lazy" />
                `}
                <div class="card-overlay">
                    <div class="card-top">
                        <div class="checkbox-custom">${isSelected ? '✓' : ''}</div>
                        <button class="fav-btn ${media.isFavorite ? 'active' : ''}" title="Favorite">★</button>
                    </div>
                    <div class="card-bottom">
                        <div class="card-title">${this.escapeHtml(media.name)}</div>
                    </div>
                </div>
            `;

            // Card click handlers
            card.addEventListener('click', (e) => {
                if (e.target.classList.contains('fav-btn')) {
                    e.stopPropagation();
                    this.toggleFavorite(media);
                } else if (e.target.classList.contains('checkbox-custom') || e.ctrlKey || e.metaKey) {
                    e.stopPropagation();
                    this.toggleSelectMedia(media.id);
                } else {
                    this.openViewer(index);
                }
            });

            grid.appendChild(card);
        }

        this.updateBatchBar();
    }

    async toggleFavorite(media) {
        media.isFavorite = !media.isFavorite;
        await this.db.saveMedia(media);
        await this.loadGallery();
    }

    toggleSelectMedia(id) {
        if (this.selectedMediaIds.has(id)) {
            this.selectedMediaIds.delete(id);
        } else {
            this.selectedMediaIds.add(id);
        }
        this.updateBatchBar();
        this.loadGallery();
    }

    selectAllMedia() {
        if (this.selectedMediaIds.size === this.currentMediaList.length) {
            this.selectedMediaIds.clear();
        } else {
            this.currentMediaList.forEach(m => this.selectedMediaIds.add(m.id));
        }
        this.updateBatchBar();
        this.loadGallery();
    }

    updateBatchBar() {
        const batchBar = document.getElementById('batch-bar');
        const countEl = document.getElementById('selected-count');

        if (this.selectedMediaIds.size > 0) {
            batchBar.style.display = 'flex';
            countEl.innerText = `${this.selectedMediaIds.size} selected`;
        } else {
            batchBar.style.display = 'none';
        }
    }

    async deleteSelectedMedia() {
        if (this.selectedMediaIds.size === 0) return;
        if (confirm(`Delete ${this.selectedMediaIds.size} selected item(s) permanently?`)) {
            await this.db.deleteMultipleMedia(Array.from(this.selectedMediaIds));
            this.selectedMediaIds.clear();
            this.showToast('Selected item(s) deleted', 'info');
            await this.loadGallery();
            await this.updateStorageUsage();
        }
    }

    // --- FULLSCREEN LIGHTBOX VIEWER ---

    async openViewer(index) {
        if (index < 0 || index >= this.currentMediaList.length) return;
        this.currentViewerIndex = index;
        this.viewerZoom = 1;
        this.viewerRotation = 0;

        const media = this.currentMediaList[index];
        const modal = document.getElementById('viewer-modal');
        const container = document.getElementById('viewer-container');
        
        container.innerHTML = '<div style="color:#94a3b8;">Decrypting media...</div>';
        modal.classList.add('active');

        try {
            const decryptedBuf = await VaultCrypto.decryptData(media.encryptedBlob, this.currentCryptoKey, media.iv);
            const blob = new Blob([decryptedBuf], { type: media.mimeType });
            const mediaUrl = URL.createObjectURL(blob);
            this.blobUrls.push(mediaUrl);

            if (media.type === 'video') {
                container.innerHTML = `<video src="${mediaUrl}" controls autoplay style="max-width:100%; max-height:100%;"></video>`;
            } else {
                container.innerHTML = `<img id="viewer-img" src="${mediaUrl}" style="transform: scale(1) rotate(0deg);" />`;
            }

            // Update viewer details panel
            document.getElementById('viewer-filename').innerText = media.name;
            document.getElementById('viewer-info-size').innerText = (media.size / (1024 * 1024)).toFixed(2) + ' MB';
            document.getElementById('viewer-info-type').innerText = media.mimeType;
            document.getElementById('viewer-info-date').innerText = new Date(media.dateAdded).toLocaleString();
            document.getElementById('viewer-info-enc').innerText = 'AES-256-GCM (96-bit IV)';

        } catch (e) {
            console.error("Viewer decryption error:", e);
            container.innerHTML = '<div style="color:#f43f5e;">Failed to decrypt file payload.</div>';
        }
    }

    navigateViewer(direction) {
        const newIndex = this.currentViewerIndex + direction;
        if (newIndex >= 0 && newIndex < this.currentMediaList.length) {
            this.openViewer(newIndex);
        }
    }

    zoomViewer(delta) {
        this.viewerZoom = Math.max(0.5, Math.min(3, this.viewerZoom + delta));
        this.applyViewerTransform();
    }

    rotateViewer() {
        this.viewerRotation = (this.viewerRotation + 90) % 360;
        this.applyViewerTransform();
    }

    applyViewerTransform() {
        const img = document.getElementById('viewer-img');
        if (img) {
            img.style.transform = `scale(${this.viewerZoom}) rotate(${this.viewerRotation}deg)`;
        }
    }

    async downloadCurrentViewerMedia() {
        if (this.currentViewerIndex < 0) return;
        const media = this.currentMediaList[this.currentViewerIndex];

        const decryptedBuf = await VaultCrypto.decryptData(media.encryptedBlob, this.currentCryptoKey, media.iv);
        const blob = new Blob([decryptedBuf], { type: media.mimeType });
        const url = URL.createObjectURL(blob);

        const a = document.createElement('a');
        a.href = url;
        a.download = media.name;
        a.click();
        URL.revokeObjectURL(url);
    }

    // --- CANVAS CENSOR / BLUR EDITOR ---

    async openRedactor() {
        if (this.currentViewerIndex < 0) return;
        const media = this.currentMediaList[this.currentViewerIndex];
        if (media.type !== 'image') {
            this.showToast('Censor tool is available for images only', 'info');
            return;
        }

        const modal = document.getElementById('editor-modal');
        this.editorCanvas = document.getElementById('editor-canvas');
        this.editorCtx = this.editorCanvas.getContext('2d');

        const decryptedBuf = await VaultCrypto.decryptData(media.encryptedBlob, this.currentCryptoKey, media.iv);
        const blob = new Blob([decryptedBuf], { type: media.mimeType });
        const mediaUrl = URL.createObjectURL(blob);

        this.editorImg = new Image();
        this.editorImg.onload = () => {
            this.editorCanvas.width = this.editorImg.width;
            this.editorCanvas.height = this.editorImg.height;
            this.editorCtx.drawImage(this.editorImg, 0, 0);
            URL.revokeObjectURL(mediaUrl);
            modal.classList.add('active');
        };
        this.editorImg.src = mediaUrl;
    }

    applyCensorBox(startX, startY, width, height, mode) {
        if (width === 0 || height === 0) return;

        if (mode === 'blackout') {
            this.editorCtx.fillStyle = '#000000';
            this.editorCtx.fillRect(startX, startY, width, height);
        } else if (mode === 'blur') {
            // Extract sub-image, pixelate / blur it
            const imgData = this.editorCtx.getImageData(startX, startY, width, height);
            const pixelSize = 12;

            for (let y = 0; y < height; y += pixelSize) {
                for (let x = 0; x < width; x += pixelSize) {
                    const i = (y * width + x) * 4;
                    const r = imgData.data[i];
                    const g = imgData.data[i + 1];
                    const b = imgData.data[i + 2];

                    for (let py = 0; py < pixelSize && (y + py) < height; py++) {
                        for (let px = 0; px < pixelSize && (x + px) < width; px++) {
                            const pi = ((y + py) * width + (x + px)) * 4;
                            imgData.data[pi] = r;
                            imgData.data[pi + 1] = g;
                            imgData.data[pi + 2] = b;
                        }
                    }
                }
            }
            this.editorCtx.putImageData(imgData, startX, startY);
        }
    }

    async saveRedactedCopy() {
        if (!this.editorCanvas) return;

        this.editorCanvas.toBlob(async (blob) => {
            const buf = await blob.arrayBuffer();
            const encrypted = await VaultCrypto.encryptData(buf, this.currentCryptoKey);

            const mediaRecord = {
                id: 'media_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
                name: 'Redacted_' + this.currentMediaList[this.currentViewerIndex].name,
                type: 'image',
                mimeType: 'image/png',
                size: blob.size,
                albumId: this.currentAlbumId === 'all' ? 'uncategorized' : this.currentAlbumId,
                isFavorite: false,
                isDecoy: this.isDecoySession,
                dateAdded: new Date().toISOString(),
                iv: encrypted.iv,
                encryptedBlob: encrypted.ciphertext
            };

            await this.db.saveMedia(mediaRecord);
            document.getElementById('editor-modal').classList.remove('active');
            this.showToast('Redacted copy saved to vault!', 'success');
            await this.loadGallery();
        }, 'image/png');
    }

    // --- DEMO SAMPLE MEDIA GENERATOR ---

    async generateDemoPhotos() {
        this.showToast('Generating demo encrypted photos...', 'info');

        const samples = [
            { title: 'Private Document Scan.png', color1: '#1e1b4b', color2: '#4338ca', text: 'CONFIDENTIAL DOCUMENT\nCLASSIFIED ACCESS ONLY' },
            { title: 'Secret Passport Copy.png', color1: '#064e3b', color2: '#047857', text: 'OFFICIAL IDENTITY VAULT\nEXIF & GPS STRIPPED' },
            { title: 'Encrypted Snapshot.png', color1: '#701a75', color2: '#a21caf', text: 'SHADOWVAULT AES-256\nPROTECTED MEMORY' }
        ];

        for (const sample of samples) {
            const canvas = document.createElement('canvas');
            canvas.width = 800;
            canvas.height = 800;
            const ctx = canvas.getContext('2d');

            // Gradient background
            const grad = ctx.createLinearGradient(0, 0, 800, 800);
            grad.addColorStop(0, sample.color1);
            grad.addColorStop(1, sample.color2);
            ctx.fillStyle = grad;
            ctx.fillRect(0, 0, 800, 800);

            // Watermark text
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 36px sans-serif';
            ctx.textAlign = 'center';
            const lines = sample.text.split('\n');
            lines.forEach((line, i) => {
                ctx.fillText(line, 400, 380 + i * 50);
            });

            ctx.font = '16px monospace';
            ctx.fillStyle = 'rgba(255,255,255,0.6)';
            ctx.fillText('Encrypted on client-side via WebCrypto API', 400, 720);

            const blob = await new Promise(res => canvas.toBlob(res, 'image/png'));
            const buf = await blob.arrayBuffer();
            const encrypted = await VaultCrypto.encryptData(buf, this.currentCryptoKey);

            const record = {
                id: 'demo_' + Date.now() + '_' + Math.floor(Math.random()*1000),
                name: sample.title,
                type: 'image',
                mimeType: 'image/png',
                size: blob.size,
                albumId: 'uncategorized',
                isFavorite: false,
                isDecoy: this.isDecoySession,
                dateAdded: new Date().toISOString(),
                iv: encrypted.iv,
                encryptedBlob: encrypted.ciphertext
            };

            await this.db.saveMedia(record);
        }

        this.showToast('3 Demo photos encrypted & added!', 'success');
        await this.loadGallery();
        await this.updateStorageUsage();
    }

    // --- EXPORT & IMPORT VAULT BACKUP ---

    async exportVaultBackup() {
        const items = await this.db.getAllMedia(this.isDecoySession);
        const albums = await this.db.getAlbums(this.isDecoySession);

        if (items.length === 0) {
            this.showToast('No items to export', 'info');
            return;
        }

        this.showToast('Preparing encrypted vault export...', 'info');

        const exportItems = items.map(item => ({
            id: item.id,
            name: item.name,
            type: item.type,
            mimeType: item.mimeType,
            size: item.size,
            albumId: item.albumId,
            isFavorite: item.isFavorite,
            dateAdded: item.dateAdded,
            iv: item.iv,
            // Convert ArrayBuffer to Base64
            encryptedDataB64: btoa(String.fromCharCode(...new Uint8Array(item.encryptedBlob)))
        }));

        const backupData = {
            vaultVersion: '1.0',
            exportedAt: new Date().toISOString(),
            albums: albums,
            media: exportItems
        };

        const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `ShadowVault_Backup_${new Date().toISOString().slice(0,10)}.svault`;
        a.click();
        URL.revokeObjectURL(url);

        this.showToast('Vault backup exported successfully!', 'success');
    }

    async importVaultBackup(file) {
        try {
            const text = await file.text();
            const data = JSON.parse(text);

            if (!data.media || !Array.isArray(data.media)) {
                throw new Error("Invalid backup format");
            }

            this.showToast(`Importing ${data.media.length} item(s)...`, 'info');

            for (const item of data.media) {
                // Convert Base64 back to ArrayBuffer
                const binaryStr = atob(item.encryptedDataB64);
                const bytes = new Uint8Array(binaryStr.length);
                for (let i = 0; i < binaryStr.length; i++) {
                    bytes[i] = binaryStr.charCodeAt(i);
                }

                const record = {
                    id: item.id || ('imported_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6)),
                    name: item.name,
                    type: item.type,
                    mimeType: item.mimeType,
                    size: item.size,
                    albumId: item.albumId || 'uncategorized',
                    isFavorite: !!item.isFavorite,
                    isDecoy: this.isDecoySession,
                    dateAdded: item.dateAdded || new Date().toISOString(),
                    iv: item.iv,
                    encryptedBlob: bytes.buffer
                };

                await this.db.saveMedia(record);
            }

            if (data.albums && Array.isArray(data.albums)) {
                for (const album of data.albums) {
                    await this.db.saveAlbum({ ...album, isDecoy: this.isDecoySession });
                }
            }

            this.showToast('Vault backup imported successfully!', 'success');
            await this.loadAlbums();
            await this.loadGallery();
            await this.updateStorageUsage();
        } catch (err) {
            console.error("Import error:", err);
            this.showToast('Invalid or corrupted backup file', 'error');
        }
    }

    // --- IDLE MONITOR & EVENT BINDINGS ---

    startIdleMonitor() {
        const resetTimer = () => {
            if (this.idleTimer) clearTimeout(this.idleTimer);
            if (this.currentCryptoKey && this.idleMinutes > 0) {
                this.idleTimer = setTimeout(() => {
                    this.lockVault();
                    this.showToast('Auto-locked due to inactivity', 'info');
                }, this.idleMinutes * 60 * 1000);
            }
        };

        ['mousemove', 'keydown', 'touchstart'].forEach(evt => {
            window.addEventListener(evt, resetTimer);
        });

        // Lock on tab blur / window visibility change if enabled
        document.addEventListener('visibilitychange', () => {
            const lockOnBlur = localStorage.getItem('vault_lock_on_blur') === 'true';
            if (document.hidden && lockOnBlur && this.currentCryptoKey) {
                this.lockVault();
            }
        });

        // Panic key: Escape key instantly locks vault
        window.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.currentCryptoKey) {
                this.lockVault();
            }
        });
    }

    async updateStorageUsage() {
        const items = await this.db.getAllMedia(this.isDecoySession);
        const totalBytes = items.reduce((sum, item) => sum + (item.size || 0), 0);
        const totalMb = (totalBytes / (1024 * 1024)).toFixed(1);

        document.getElementById('storage-usage-text').innerText = `${totalMb} MB used (${items.length} items)`;
        // Assume 50MB soft limit display
        const pct = Math.min(100, Math.round((totalBytes / (50 * 1024 * 1024)) * 100));
        document.getElementById('storage-progress-bar').style.width = `${pct}%`;
    }

    updateNavCounts(currentCount) {
        document.getElementById('count-all').innerText = currentCount;
    }

    showToast(message, type = 'info') {
        const container = document.getElementById('toast-container');
        const toast = document.createElement('div');
        toast.className = 'toast';
        toast.innerHTML = `<span>${type === 'success' ? '✓' : type === 'error' ? '⚠️' : 'ℹ️'}</span> <span>${this.escapeHtml(message)}</span>`;
        container.appendChild(toast);

        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    escapeHtml(str) {
        return (str || '').replace(/[&<>"']/g, m => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
        })[m]);
    }

    bindEvents() {
        // PIN Pad Buttons
        document.querySelectorAll('#pin-keypad .key-btn[data-val]').forEach(btn => {
            btn.addEventListener('click', () => this.handlePinInput(btn.dataset.val));
        });
        document.getElementById('btn-pin-delete').addEventListener('click', () => this.handlePinDelete());

        // Calculator Buttons
        document.querySelectorAll('#calc-grid .calc-btn').forEach(btn => {
            btn.addEventListener('click', () => this.handleCalcInput(btn.innerText));
        });

        // Mode switchers
        document.getElementById('btn-stealth-calc').addEventListener('click', () => {
            localStorage.setItem('vault_stealth_mode', 'true');
            this.switchScreen('calculator-screen');
        });

        document.getElementById('btn-lock-now').addEventListener('click', () => this.lockVault());

        // Setup Form
        document.getElementById('setup-form').addEventListener('submit', (e) => {
            e.preventDefault();
            const pin = document.getElementById('setup-pin').value;
            const decoy = document.getElementById('setup-decoy-pin').value;
            this.setupVaultPasscode(pin, decoy);
        });

        // File Upload Dropzone
        const fileInput = document.getElementById('file-input');
        document.getElementById('btn-upload-media').addEventListener('click', () => fileInput.click());
        fileInput.addEventListener('change', (e) => this.handleFileUpload(e.target.files));

        const dropzone = document.getElementById('dropzone');
        dropzone.addEventListener('dragover', (e) => e.preventDefault());
        dropzone.addEventListener('drop', (e) => {
            e.preventDefault();
            if (e.dataTransfer.files) this.handleFileUpload(e.dataTransfer.files);
        });

        // Search Input
        document.getElementById('search-input').addEventListener('input', () => this.loadGallery());

        // Album switching
        document.querySelectorAll('.nav-item[data-album-id]').forEach(item => {
            item.addEventListener('click', () => this.switchAlbum(item.dataset.albumId, item.innerText.trim()));
        });

        document.getElementById('btn-create-album').addEventListener('click', () => this.createAlbum());

        // Batch Action Bar Buttons
        document.getElementById('btn-select-all').addEventListener('click', () => this.selectAllMedia());
        document.getElementById('btn-batch-delete').addEventListener('click', () => this.deleteSelectedMedia());

        // View Mode Toggle
        document.getElementById('btn-toggle-view').addEventListener('click', () => {
            this.viewMode = this.viewMode === 'grid' ? 'list' : 'grid';
            this.loadGallery();
        });

        // Lightbox Viewer Navigation & Actions
        document.getElementById('close-viewer').addEventListener('click', () => {
            document.getElementById('viewer-modal').classList.remove('active');
            if (this.slideshowInterval) clearInterval(this.slideshowInterval);
        });
        document.getElementById('viewer-prev-btn').addEventListener('click', () => this.navigateViewer(-1));
        document.getElementById('viewer-next-btn').addEventListener('click', () => this.navigateViewer(1));
        document.getElementById('viewer-rotate-btn').addEventListener('click', () => this.rotateViewer());
        document.getElementById('viewer-zoom-in-btn').addEventListener('click', () => this.zoomViewer(0.2));
        document.getElementById('viewer-zoom-out-btn').addEventListener('click', () => this.zoomViewer(-0.2));
        document.getElementById('viewer-download-btn').addEventListener('click', () => this.downloadCurrentViewerMedia());
        document.getElementById('viewer-censor-btn').addEventListener('click', () => this.openRedactor());

        // Censor Tool Canvas Interaction
        const canvas = document.getElementById('editor-canvas');
        canvas.addEventListener('mousedown', (e) => {
            this.isDrawingRect = true;
            const rect = canvas.getBoundingClientRect();
            const scaleX = canvas.width / rect.width;
            const scaleY = canvas.height / rect.height;
            this.rectStart = {
                x: (e.clientX - rect.left) * scaleX,
                y: (e.clientY - rect.top) * scaleY
            };
        });

        canvas.addEventListener('mouseup', (e) => {
            if (!this.isDrawingRect) return;
            this.isDrawingRect = false;
            const rect = canvas.getBoundingClientRect();
            const scaleX = canvas.width / rect.width;
            const scaleY = canvas.height / rect.height;
            const endX = (e.clientX - rect.left) * scaleX;
            const endY = (e.clientY - rect.top) * scaleY;

            const width = endX - this.rectStart.x;
            const height = endY - this.rectStart.y;

            this.applyCensorBox(this.rectStart.x, this.rectStart.y, width, height, this.editorTool);
        });

        document.getElementById('tool-blur').addEventListener('click', () => {
            this.editorTool = 'blur';
            document.getElementById('tool-blur').className = 'btn btn-primary';
            document.getElementById('tool-blackout').className = 'btn btn-secondary';
        });

        document.getElementById('tool-blackout').addEventListener('click', () => {
            this.editorTool = 'blackout';
            document.getElementById('tool-blackout').className = 'btn btn-primary';
            document.getElementById('tool-blur').className = 'btn btn-secondary';
        });

        document.getElementById('btn-save-redacted').addEventListener('click', () => this.saveRedactedCopy());
        document.getElementById('close-editor').addEventListener('click', () => {
            document.getElementById('editor-modal').classList.remove('active');
        });

        // Settings Modal & Actions
        document.getElementById('btn-settings').addEventListener('click', () => {
            document.getElementById('settings-modal').classList.add('active');
        });

        document.getElementById('close-settings').addEventListener('click', () => {
            document.getElementById('settings-modal').classList.remove('active');
        });

        document.getElementById('btn-gen-demo').addEventListener('click', () => {
            this.generateDemoPhotos();
        });

        document.getElementById('btn-export-backup').addEventListener('click', () => {
            this.exportVaultBackup();
        });

        const backupInput = document.getElementById('import-backup-input');
        document.getElementById('btn-import-backup').addEventListener('click', () => backupInput.click());
        backupInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) this.importVaultBackup(e.target.files[0]);
        });

        document.getElementById('btn-reset-vault').addEventListener('click', async () => {
            if (confirm("DANGER: Wiping vault will permanently delete all encrypted photos and reset passcode! Proceed?")) {
                await this.db.clearAllVaultData();
                localStorage.clear();
                location.reload();
            }
        });
    }
}

// Global initialization
window.addEventListener('DOMContentLoaded', () => {
    window.app = new ShadowVaultApp();
    window.app.init();
});
