/**
 * ShadowVault WebCrypto Security Engine
 * Uses AES-GCM 256-bit encryption with PBKDF2 key derivation.
 */

const VaultCrypto = {
    // Generate random IV or Salt
    randomBytes(length = 16) {
        return window.crypto.getRandomValues(new Uint8Array(length));
    },

    // Convert ArrayBuffer to Hex String
    bufferToHex(buffer) {
        return Array.from(new Uint8Array(buffer))
            .map(b => b.toString(16).padStart(2, '0'))
            .join('');
    },

    // Convert Hex String to Uint8Array
    hexToBuffer(hex) {
        const bytes = new Uint8Array(hex.length / 2);
        for (let i = 0; i < hex.length; i += 2) {
            bytes[i / 2] = parseInt(hex.substr(i, 2), 16);
        }
        return bytes;
    },

    // Convert string to Uint8Array
    strToBuf(str) {
        return new TextEncoder().encode(str);
    },

    // Convert Uint8Array to string
    bufToStr(buf) {
        return new TextDecoder().decode(buf);
    },

    // Derive AES-GCM Key from PIN/Password and Salt using PBKDF2
    async deriveKey(passcode, saltUint8) {
        const enc = new TextEncoder();
        const keyMaterial = await window.crypto.subtle.importKey(
            "raw",
            enc.encode(passcode),
            "PBKDF2",
            false,
            ["deriveKey"]
        );

        return await window.crypto.subtle.deriveKey(
            {
                name: "PBKDF2",
                salt: saltUint8,
                iterations: 100000,
                hash: "SHA-256"
            },
            keyMaterial,
            { name: "AES-GCM", length: 256 },
            false,
            ["encrypt", "decrypt"]
        );
    },

    // Compute SHA-256 hash of passcode + salt for fast authentication check
    async hashPasscode(passcode, saltHex) {
        const enc = new TextEncoder();
        const saltBytes = this.hexToBuffer(saltHex);
        const passBytes = enc.encode(passcode);
        
        const combined = new Uint8Array(passBytes.length + saltBytes.length);
        combined.set(passBytes);
        combined.set(saltBytes, passBytes.length);

        const hashBuf = await window.crypto.subtle.digest("SHA-256", combined);
        return this.bufferToHex(hashBuf);
    },

    // Encrypt ArrayBuffer or Blob
    async encryptData(arrayBuffer, cryptoKey) {
        const iv = this.randomBytes(12); // 96-bit IV for AES-GCM
        const encryptedContent = await window.crypto.subtle.encrypt(
            {
                name: "AES-GCM",
                iv: iv
            },
            cryptoKey,
            arrayBuffer
        );

        return {
            ciphertext: encryptedContent,
            iv: this.bufferToHex(iv)
        };
    },

    // Decrypt ArrayBuffer
    async decryptData(ciphertextBuffer, cryptoKey, ivHex) {
        const iv = this.hexToBuffer(ivHex);
        try {
            const decryptedContent = await window.crypto.subtle.decrypt(
                {
                    name: "AES-GCM",
                    iv: iv
                },
                cryptoKey,
                ciphertextBuffer
            );
            return decryptedContent;
        } catch (err) {
            console.error("Decryption failed. Incorrect key or tampered data.", err);
            throw new Error("Decryption failed. Passcode or key mismatch.");
        }
    }
};

window.VaultCrypto = VaultCrypto;
