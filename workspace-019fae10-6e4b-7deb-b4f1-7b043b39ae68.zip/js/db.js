/**
 * ShadowVault IndexedDB Storage Engine
 * Manages encrypted media records and album metadata locally in the browser.
 */

class VaultDB {
    constructor(dbName = "ShadowVaultDB", dbVersion = 1) {
        this.dbName = dbName;
        this.dbVersion = dbVersion;
        this.db = null;
    }

    async init() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, this.dbVersion);

            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                
                // Store for encrypted media files
                if (!db.objectStoreNames.contains("media")) {
                    const mediaStore = db.createObjectStore("media", { keyPath: "id" });
                    mediaStore.createIndex("albumId", "albumId", { unique: false });
                    mediaStore.createIndex("isDecoy", "isDecoy", { unique: false });
                    mediaStore.createIndex("isFavorite", "isFavorite", { unique: false });
                    mediaStore.createIndex("dateAdded", "dateAdded", { unique: false });
                }

                // Store for album metadata
                if (!db.objectStoreNames.contains("albums")) {
                    const albumStore = db.createObjectStore("albums", { keyPath: "id" });
                    albumStore.createIndex("isDecoy", "isDecoy", { unique: false });
                }
            };

            request.onsuccess = (event) => {
                this.db = event.target.result;
                resolve(this);
            };

            request.onerror = (event) => {
                console.error("IndexedDB initialization error:", event.target.error);
                reject(event.target.error);
            };
        });
    }

    // --- MEDIA OPERATIONS ---

    async saveMedia(mediaItem) {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction("media", "readwrite");
            const store = tx.objectStore("media");
            const request = store.put(mediaItem);

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async getMedia(id) {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction("media", "readonly");
            const store = tx.objectStore("media");
            const request = store.get(id);

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async getAllMedia(isDecoy = false) {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction("media", "readonly");
            const store = tx.objectStore("media");
            const index = store.index("isDecoy");
            const request = index.getAll(isDecoy ? 1 : 0);

            request.onsuccess = () => resolve(request.result || []);
            request.onerror = () => reject(request.error);
        });
    }

    async deleteMedia(id) {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction("media", "readwrite");
            const store = tx.objectStore("media");
            const request = store.delete(id);

            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    async deleteMultipleMedia(ids) {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction("media", "readwrite");
            const store = tx.objectStore("media");
            ids.forEach(id => store.delete(id));
            tx.oncomplete = () => resolve();
            tx.onerror = () => reject(tx.error);
        });
    }

    // --- ALBUM OPERATIONS ---

    async saveAlbum(albumItem) {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction("albums", "readwrite");
            const store = tx.objectStore("albums");
            const request = store.put(albumItem);

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async getAlbums(isDecoy = false) {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction("albums", "readonly");
            const store = tx.objectStore("albums");
            const index = store.index("isDecoy");
            const request = index.getAll(isDecoy ? 1 : 0);

            request.onsuccess = () => resolve(request.result || []);
            request.onerror = () => reject(request.error);
        });
    }

    async deleteAlbum(albumId) {
        return new Promise(async (resolve, reject) => {
            try {
                const tx = this.db.transaction(["albums", "media"], "readwrite");
                const albumStore = tx.objectStore("albums");
                const mediaStore = tx.objectStore("media");
                
                albumStore.delete(albumId);

                // Move items in deleted album back to 'uncategorized'
                const mediaIndex = mediaStore.index("albumId");
                const mediaReq = mediaIndex.getAll(albumId);

                mediaReq.onsuccess = () => {
                    const items = mediaReq.result || [];
                    items.forEach(item => {
                        item.albumId = "uncategorized";
                        mediaStore.put(item);
                    });
                };

                tx.oncomplete = () => resolve();
                tx.onerror = () => reject(tx.error);
            } catch (err) {
                reject(err);
            }
        });
    }

    async clearAllVaultData() {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(["media", "albums"], "readwrite");
            tx.objectStore("media").clear();
            tx.objectStore("albums").clear();
            tx.oncomplete = () => resolve();
            tx.onerror = () => reject(tx.error);
        });
    }
}

window.VaultDB = VaultDB;
